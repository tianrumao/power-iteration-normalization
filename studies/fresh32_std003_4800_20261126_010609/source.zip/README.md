# Fresh paired normalization study

Run 32 fresh seed pairs, 1001–1032. Each pair contains only internal normalization
on (`111`) and off (`000`). Both use four layers, d=32, n=64, initialization SD
0.03, Adam learning rate 0.0005, and exactly 4,800 updates. The cosine schedule
also spans 4,800 updates, with 100 warmup steps. The final readout is normalized
in both models.

Each new seed generates fresh unit-column Gaussian X and S=XX.T. The backbone
predicts the true leading eigenvector. Paired models share initial weights,
data, batch indices, precision and schedule. Initial and batch fingerprints are
checked for every pair. Use a new output and cache directory for this run.
Previous experiments' checkpoints and results are not inputs to this cohort.

The final gap is the absolute difference between the models' fourth-layer
validation mean(1 - squared cosine) errors. Record all seeds; flag gaps strictly
greater than 0.1. Do not drop flagged seeds or stop at the first flagged pair.
After at least eight completed pairs, automatically pause if more than 50% of
completed pairs are flagged. Save a pause record, cumulative counts and plots.
Numerical or implementation failures also halt and preserve diagnostics.

Every completed pair immediately updates `pairs.json`, `progress.json`,
`seed-gaps.csv` and `seed-gap.png`. The two-column CSV contains only seed and
final_gap. The plot shows one final gap per seed; gaps above 0.1 are red, with
a dashed threshold line. All model errors and fingerprints remain in separate
full records. Neither test scores nor intermediate probes define the flag.

Training and gap reporting come first. After all seeds finish without triggering
the pause rule, evaluate all models, including flagged ones, on the test, probe
and bypass datasets. Independently calibrate eight direction targets through
power 16. Every input/network layer gets eight bias-free linear direction probes,
with separate fit/validation/test partitions, three split seeds, fixed readout,
shuffled-label controls and cross-target scores. The task target remains the true
eigenvector. Save plain bypass and length-matched bypass for each network layer.
Save all-model summaries and an additional summary for pairs with gap <= 0.1.

Use `train.ipynb` in Google Colab with a GPU. Upload `source_fresh32.zip` through
the Files panel, then run setup, Drive mounting, calibration and training.
Paths are defined in one cell. Source snapshots, configuration, data fingerprints,
validation histories, checkpoints and analysis files are saved under the new run.
The same run supports recovery from its own 200-update checkpoints; a changed
configuration or source requires a new output directory. A `pause.request` file
in the run directory prevents starting another seed.

Run software checks with `python -m unittest discover -s tests -q`.
