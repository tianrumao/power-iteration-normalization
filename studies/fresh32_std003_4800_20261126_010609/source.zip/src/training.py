"""Train each normalization condition to the same fixed update budget."""

import json
import numpy as np
import torch

from src.model import readout, direction_error
from .io import atomic_json, digest
from .metrics import score
from .model import Model
import math


def model_for(mask, std, device, precision="float64"):
    if mask not in ("111", "000"):
        raise ValueError("Only 111 and 000 are supported")
    dtype = {"float32": torch.float32, "float64": torch.float64}[precision]
    return Model(32, mask == "111", std).to(device=device, dtype=dtype)


def cpu_state(model):
    return {name: value.detach().cpu().clone() for name, value in model.state_dict().items()}


def learning_rate(step, cfg):
    warmup, horizon = cfg["warmup_steps"], cfg["schedule_horizon"]
    if step < warmup:
        return cfg["learning_rate"] * (step + 1) / warmup
    phase = (step - warmup) / max(horizon - warmup - 1, 1)
    return cfg["learning_rate"] * (.1 + .9 * (1 + math.cos(math.pi * phase)) / 2)


def train_arm(seed, mask, cfg, pools, output, device):
    folder = output / f"seed-{seed}" / mask
    folder.mkdir(parents=True, exist_ok=True)
    if (folder / "selection.json").exists():
        return json.loads((folder / "selection.json").read_text())
    torch.manual_seed(seed)
    model = model_for(mask, cfg["init_std"], device, cfg["precision"])
    initial = cpu_state(model)
    initial_hash = digest(np.concatenate([v.numpy().ravel() for v in initial.values()]))
    dtype = next(model.parameters()).dtype
    optimizer = torch.optim.Adam(model.parameters(), lr=cfg["learning_rate"])
    rng = np.random.default_rng(np.random.SeedSequence([cfg["data_epoch"], seed, 4402]))
    maximum = max(cfg["budgets"])
    batches = rng.integers(0, cfg["train_size"], (maximum, cfg["batch_size"]))
    atomic_json(folder / "pairing.json", {"initial_sha256": initial_hash,
        "batch_sha256": digest(batches), "seed": seed, "mask": mask})
    checkpoint = folder / "resume.pt"
    step, history = 0, []
    if checkpoint.exists():
        saved = torch.load(checkpoint, map_location=device, weights_only=True)
        model.load_state_dict(saved["model"])
        optimizer.load_state_dict(saved["optimizer"])
        step, history = saved["step"], saved["history"]
    x, y = (v.to(device=device, dtype=dtype) for v in pools["train"])
    validation = None
    # A saved checkpoint represents the state after its validation event.
    if not history:
        validation, _ = score(model, pools["validation"], device)
        history.append({"step": 0, **validation})
    for step in range(step + 1, maximum + 1):
        optimizer.param_groups[0]["lr"] = learning_rate(step - 1, cfg)
        ids = batches[step - 1]
        optimizer.zero_grad(set_to_none=True)
        states, _ = model(x[ids])
        prediction, valid = readout(states[-1])
        loss = direction_error(prediction, y[ids], valid).mean()
        if not valid.all() or not torch.isfinite(loss):
            raise FloatingPointError(f"Invalid model output at update {step}")
        loss.backward()
        if not all(torch.isfinite(p.grad).all() for p in model.parameters()):
            raise FloatingPointError(f"Invalid model gradient at update {step}")
        optimizer.step()
        if step % cfg["evaluation_every"] == 0 or step == maximum:
            validation, _ = score(model, pools["validation"], device)
            history.append({"step": step, **validation})
            atomic_json(folder / "history.json", history)
            torch.save({"model": cpu_state(model), "optimizer": optimizer.state_dict(),
                        "step": step, "history": history},
                       folder / "resume.pending")
            (folder / "resume.pending").replace(checkpoint)
            print(f"seed={seed} mask={mask} step={step} validation={validation['mean_error']:.6f}", flush=True)
    if validation is None:
        validation = history[-1]
    torch.save(cpu_state(model), folder / "selected.pt")
    result = {"seed": seed, "mask": mask, "selected_step": step,
              "budget_complete": step == maximum, "validation_error": validation["mean_error"],
              "invalid_outputs": validation["failures"], "precision": cfg["precision"]}
    atomic_json(folder / "selection.json", result)
    return result
