import torch
from torch import nn


def unit(vector, dim):
    # The largest finite coordinate may have a square outside the dtype range.
    # Scaling by a positive constant cancels from both the unit vector and its
    # derivative, so the scale can be detached from the gradient computation.
    scale = vector.detach().abs().amax(dim=dim, keepdim=True)
    valid = torch.isfinite(scale) & (scale > 0)
    scaled = torch.where(valid, vector, 0.0) / torch.where(valid, scale, 1.0)
    length = torch.linalg.vector_norm(scaled, dim=dim, keepdim=True)
    return scaled / torch.where(valid, length, 1.0), valid.squeeze(dim)


def normalize_tokens(tokens):
    normalized, valid = unit(tokens, -2)
    return torch.where(valid.unsqueeze(-2), normalized, tokens)


def match_lengths(tokens, reference):
    directions, valid = unit(tokens, -2)
    # Form the rescaled coordinates before multiplying by the reference peak.
    # The scalar length itself may exceed the dtype even when the requested
    # output coordinates are representable.
    peak = reference.abs().amax(dim=-2, keepdim=True)
    finite = torch.isfinite(peak)
    relative = torch.where(finite, reference, 0.0) / torch.where(finite & (peak > 0), peak, 1.0)
    factor = torch.linalg.vector_norm(relative, dim=-2, keepdim=True)
    matched = (directions * factor) * peak
    zero = (tokens == 0).all(dim=-2)
    possible = (valid | (zero & (peak.squeeze(-2) == 0))) & torch.isfinite(matched).all(dim=-2)
    return matched, possible.all(dim=-1)


def readout(tokens):
    d = tokens.shape[-2] // 2
    return unit(tokens[:, d:, -1], -1)


def direction_error(prediction, target, valid):
    alignment = (prediction * target).sum(dim=-1).clamp(-1, 1)
    return torch.where(valid, 1 - alignment.square(), 1.0)


class Block(nn.Module):
    def __init__(self, width, std):
        super().__init__()
        self.v = nn.Parameter(torch.randn(width, width) * std)
        self.w = nn.Parameter(torch.randn(width, width) * std)

    def forward(self, tokens):
        return tokens + self.v @ ((tokens @ tokens.transpose(-1, -2)) @ (self.w @ tokens))


class Model(nn.Module):
    def __init__(self, d, norm_on, init_std, *, norm_layers=None, depth=4):
        super().__init__()
        if depth < 1:
            raise ValueError("Depth must be positive")
        self.blocks = nn.ModuleList(Block(2 * d, init_std) for _ in range(depth))
        self.norm_on = norm_on
        self.norm_layers = None if norm_layers is None else tuple(norm_layers)
        if self.norm_layers is not None and len(self.norm_layers) != len(self.blocks):
            raise ValueError("Provide one normalization switch for each layer")

    def forward(self, tokens, bypass=None, reference=None):
        if bypass is not None and bypass not in range(len(self.blocks)):
            raise ValueError("Bypass index is outside the network")
        if reference is not None and bypass is None:
            raise ValueError("Length matching requires a bypassed layer")
        states = []
        possible = torch.ones(tokens.shape[0], dtype=torch.bool, device=tokens.device)
        norm_layers = self.norm_layers
        if norm_layers is None:
            norm_layers = (self.norm_on,) * (len(self.blocks) - 1) + (False,)
        for layer, block in enumerate(self.blocks):
            if layer != bypass:
                tokens = block(tokens)
            if norm_layers[layer]:
                tokens = normalize_tokens(tokens)
            if layer == bypass and reference is not None:
                tokens, possible = match_lengths(tokens, reference)
            states.append(tokens)
        return states, possible
