"""Power-method direction labels and calibration-only target selection."""

import numpy as np

from src.data import sample


def normalize(values):
    values = np.asarray(values, dtype=np.float64)
    if not np.isfinite(values).all():
        raise ValueError("Directions must be finite")
    peak = np.max(np.abs(values), axis=-1, keepdims=True)
    scaled = values / np.where(peak > 0, peak, 1)
    length = np.linalg.norm(scaled, axis=-1, keepdims=True)
    return scaled / np.where(length > 0, length, 1)


def power_directions(tokens, max_power=16):
    """Return q_0,...,q_K from the actual encoded X and start vector."""
    tokens = np.asarray(tokens, dtype=np.float64)
    if tokens.ndim != 3 or tokens.shape[1] % 2 or max_power < 1:
        raise ValueError("Expected [samples, 2*d, n+1] tokens and positive max_power")
    d = tokens.shape[1] // 2
    x = tokens[:, :d, :-1]
    covariance = x @ x.swapaxes(-1, -2)
    directions = [normalize(tokens[:, d:, -1])]
    for _ in range(max_power):
        update = (covariance @ directions[-1][..., None])[..., 0]
        directions.append(normalize(update))
    result = np.stack(directions, axis=1)
    if not np.allclose(np.linalg.norm(result, axis=-1), 1):
        raise ValueError("A power iterate has zero length")
    return result


def target_geometry(directions):
    cosine = np.einsum("nid,njd->nij", directions, directions).clip(-1, 1)
    errors = 1 - cosine**2
    angles = np.degrees(np.arccos(np.abs(cosine)))
    return {
        "mean_direction_error": errors.mean(axis=0).tolist(),
        "mean_angle_degrees": angles.mean(axis=0).tolist(),
        "angle_p10_degrees": np.quantile(angles, .1, axis=0).tolist(),
        "angle_p90_degrees": np.quantile(angles, .9, axis=0).tolist(),
    }


def select_powers(directions, count=8):
    """Greedy maximin mean squared-sine distance, anchoring q_1 and q_K."""
    maximum = directions.shape[1] - 1
    if not 2 <= count <= maximum:
        raise ValueError("Require 2 <= count <= max_power")
    geometry = target_geometry(directions)
    distance = np.asarray(geometry["mean_direction_error"])
    selected = [1, maximum]
    while len(selected) < count:
        candidates = set(range(1, maximum + 1)) - set(selected)
        selected.append(max(candidates, key=lambda k: (min(distance[k, selected]), -k)))
    return sorted(selected), geometry


def calibrate(d=32, n=64, samples=2048, seed=20261125, maximum=16, count=8):
    examples = sample(samples, d, n, np.random.default_rng(seed), power_steps=0)
    directions = power_directions(examples.tokens, maximum)
    selected, geometry = select_powers(directions, count)
    eigen_error = 1 - np.sum(directions * examples.target[:, None], axis=-1)**2
    return {
        "source": "independent calibration; no model fitting or test-set selection",
        "d": d, "n": n, "samples": samples, "seed": seed,
        "max_power": maximum, "powers": selected,
        "method": "greedy maximin mean squared-sine distance; endpoints 1 and K fixed",
        "geometry": geometry,
        "mean_error_to_eigenvector": eigen_error.mean(axis=0).tolist(),
        "eigenvalue_ratio_quantiles": np.quantile(examples.eigenvalue_ratio, [.1, .5, .9]).tolist(),
    }
