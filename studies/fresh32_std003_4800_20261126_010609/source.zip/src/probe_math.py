"""Query feature extraction and fixed probe data partitions."""

import numpy as np
import torch
from .model import readout

def tensor(array, device):
    return torch.as_tensor(array, dtype=torch.float32, device=device)

def split_indices(count, seed):
    permutation = np.random.RandomState(seed).permutation(count)
    test_count = min(max(int(round(0.3 * count)), 1), count - 1)
    return (permutation[test_count:], permutation[:test_count])

@torch.no_grad()
def collect_query_states(model, tokens, batch_size, device):
    features = []
    fixed = []
    for start in range(0, len(tokens), batch_size):
        inputs = tensor(tokens[start:start + batch_size], device).to(dtype=next(model.parameters()).dtype)
        states, _ = model(inputs)
        layers = [inputs, *states]
        features.append(np.stack([state[:, :, -1].double().cpu().numpy() for state in layers]))
        fixed.append(np.stack([readout(state)[0].double().cpu().numpy() for state in layers]))
    return (np.concatenate(features, axis=1), np.concatenate(fixed, axis=1))
