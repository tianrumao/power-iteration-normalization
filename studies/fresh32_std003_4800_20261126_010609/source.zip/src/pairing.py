"""Validation-only pairing and length-matched layer bypass."""

import numpy as np
import torch

from src.model import readout, direction_error


def qualify_pair(on, off, maximum_gap=.1, required_step=None):
    if on is None or off is None:
        return {"eligible": False, "reason": "missing_or_failed_arm"}
    if required_step is not None and any(arm.get("selected_step") != required_step for arm in (on, off)):
        return {"eligible": False, "reason": "incomplete_budget"}
    values = [on["validation_error"], off["validation_error"]]
    if not np.isfinite(values).all():
        return {"eligible": False, "reason": "nonfinite_validation_error"}
    if on.get("invalid_outputs", 0) or off.get("invalid_outputs", 0):
        return {"eligible": False, "reason": "invalid_output"}
    gap = abs(values[0] - values[1])
    return {"eligible": gap <= maximum_gap,
            "reason": "passed" if gap <= maximum_gap else "validation_gap",
            "validation_gap": gap}


@torch.no_grad()
def bypass_layers(model, dataset, device, batch_size=64):
    """Skip one residual update, keeping its normalizer; match lengths as control."""
    inputs, targets = dataset
    depth = len(model.blocks)
    scores = {(mode, layer): [] for mode in ("bypass", "matched") for layer in range(depth)}
    failures = {key: 0 for key in scores}
    intact = []
    intact_failures = 0
    dtype = next(model.parameters()).dtype
    for start in range(0, len(inputs), batch_size):
        x = inputs[start:start + batch_size].to(device=device, dtype=dtype)
        y = targets[start:start + batch_size].to(device=device, dtype=dtype)
        states, _ = model(x)
        prediction, valid = readout(states[-1])
        intact.append(direction_error(prediction, y, valid).cpu().numpy())
        intact_failures += int((~valid).sum())
        for (mode, layer), values in scores.items():
            changed, possible = model(x, bypass=layer,
                reference=states[layer] if mode == "matched" else None)
            prediction, valid = readout(changed[-1])
            valid = valid & possible
            values.append(direction_error(prediction, y, valid).cpu().numpy())
            failures[mode, layer] += int((~valid).sum())
    intact = np.concatenate(intact)
    rows = []
    for (mode, layer), values in scores.items():
        errors = np.concatenate(values)
        rows.append({"mode": mode, "layer": layer + 1, "samples": len(intact),
                     "intact_error": float(intact.mean()),
                     "mean_error": float(errors.mean()),
                     "delta_final_error": float((errors - intact).mean()),
                     "invalid_outputs": failures[mode, layer],
                     "intact_invalid_outputs": intact_failures})
    contrast = {}
    for mode in ("bypass", "matched"):
        costs = {r["layer"]: r["delta_final_error"] for r in rows if r["mode"] == mode}
        contrast[mode] = costs[depth] - costs[1]
    return rows, contrast
