"""Independent linear direction probes for every layer and selected power."""

import numpy as np
import torch

from src.model import unit
from .power_targets import normalize
from .probe_math import split_indices


def similarity(prediction, target):
    direction, valid = unit(prediction, -1)
    alignment = (direction * target).sum(-1).clamp(-1, 1)
    return torch.where(valid, alignment.square(), 0)


def partition(samples, split_seed):
    outer_train, test = split_indices(samples, split_seed)
    order = np.random.RandomState(1000 + split_seed).permutation(outer_train)
    fit_count = int(.8 * len(order))
    if min(fit_count, len(order) - fit_count, len(test)) < 1:
        raise ValueError("Need enough samples for fit, validation and test")
    return order[:fit_count], order[fit_count:], test


def fit_maps(features, targets, fit, validation, *, steps=300, learning_rate=.01,
             batch_size=256, seed=0, device="cpu", restarts=("fixed", "random")):
    """Fit bias-free maps with sign-invariant loss; select on validation only.

    Features have shape [layers, samples, 2*d], targets [powers, samples, d].
    Positive per-example scaling cancels at output normalization. No centering
    or bias is used, so every predictor remains a linear directional readout.
    """
    if steps < 0 or not np.isfinite(features).all() or not np.isfinite(targets).all():
        raise ValueError("Invalid probe inputs")
    layers, _, width = features.shape
    powers, _, d = targets.shape
    if width != 2 * d:
        raise ValueError("Expected full 2*d query features")
    features = normalize(features)
    rms = np.sqrt(np.mean(features[:, fit]**2, axis=1, keepdims=True))
    rms = np.where(rms < 1e-12, 1, rms)
    z = torch.as_tensor(features / rms, dtype=torch.float64, device=device)
    y = torch.as_tensor(normalize(targets), dtype=torch.float64, device=device)
    initial = np.zeros((layers, powers, d, width))
    for layer in range(layers):
        initial[layer, :, np.arange(d), d + np.arange(d)] = rms[layer, 0, d:][:, None]
    fixed = torch.as_tensor(initial, dtype=z.dtype, device=device)
    best_weights = fixed.clone()
    best_value = torch.full((layers, powers), -1., dtype=z.dtype, device=device)
    best_step = np.zeros((layers, powers), dtype=int)
    best_restart = np.full((layers, powers), "fixed", dtype="U8")
    generator = torch.Generator(device=device).manual_seed(seed)
    for restart in restarts:
        if restart == "fixed":
            weights = torch.nn.Parameter(fixed.clone())
        elif restart == "random":
            weights = torch.nn.Parameter(torch.randn(
                initial.shape, dtype=z.dtype, device=device, generator=generator) / np.sqrt(width))
        else:
            raise ValueError("Unknown restart")
        optimizer = torch.optim.Adam([weights], lr=learning_rate)
        rng = np.random.default_rng(seed)
        for step in range(steps + 1):
            if step % 25 == 0 or step == steps:
                with torch.no_grad():
                    predictions = torch.einsum("lnf,ltdf->ltnd", z[:, validation], weights)
                    current = similarity(predictions, y[:, validation][None]).mean(-1)
                    if not torch.isfinite(current).all():
                        raise FloatingPointError("Nonfinite probe validation score")
                    improved = current > best_value
                    best_value[improved] = current[improved]
                    best_weights[improved] = weights.detach()[improved]
                    changed = improved.cpu().numpy()
                    best_step[changed] = step
                    best_restart[changed] = restart
            if step == steps:
                break
            indices = fit[rng.integers(0, len(fit), batch_size)]
            optimizer.zero_grad(set_to_none=True)
            predictions = torch.einsum("lnf,ltdf->ltnd", z[:, indices], weights)
            loss = (1 - similarity(predictions, y[:, indices][None])).mean(-1).sum()
            loss.backward()
            if not torch.isfinite(loss) or not torch.isfinite(weights.grad).all():
                raise FloatingPointError("Nonfinite probe fit")
            optimizer.step()
    return {
        "weights": best_weights.cpu().numpy(), "rms": rms,
        "validation_similarity": best_value.cpu().numpy(),
        "best_step": best_step, "restart": best_restart,
    }


def predict_maps(features, fitted):
    z = normalize(features) / fitted["rms"]
    return normalize(np.einsum("lnf,ltdf->ltnd", z, fitted["weights"]))


def score_maps(features, targets, fitted, indices):
    prediction = predict_maps(features[:, indices], fitted)
    target = normalize(targets[:, indices])
    cosine = np.einsum("ltnd,tnd->ltn", prediction, target).clip(-1, 1)
    values = cosine**2
    cross = np.einsum("ltnd,jnd->ltjn", prediction, target).clip(-1, 1)**2
    return values, cross.mean(-1)


def probe_powers(features, directions, powers, cfg, output, metadata, device="cpu"):
    from .io import atomic_json, write_csv

    powers = list(powers)
    if len(set(powers)) != len(powers) or min(powers) < 1 or max(powers) >= directions.shape[1]:
        raise ValueError("Powers must be distinct positive available steps")
    targets = directions[:, powers].transpose(1, 0, 2)
    layers, samples, width = features.shape
    d = width // 2
    output.mkdir(parents=True, exist_ok=True)
    rows, cross_rows = [], []
    for split_seed in cfg.get("probe_split_seeds", [0, 1, 2]):
        fit, validation, test = partition(samples, split_seed)
        settings = dict(steps=cfg.get("probe_steps", 300),
                        batch_size=cfg.get("probe_batch_size", 256),
                        learning_rate=cfg.get("probe_learning_rate", .01),
                        seed=20261125 + 31 * metadata["seed"] + split_seed,
                        device=device)
        fitted = fit_maps(features, targets, fit, validation, **settings)
        values, cross = score_maps(features, targets, fitted, test)
        rng = np.random.default_rng(settings["seed"] + 1)
        shuffled_targets = targets.copy()
        for indices in (fit, validation):
            shuffled_targets[:, indices] = targets[:, rng.permutation(indices)]
        shuffled = fit_maps(features, shuffled_targets, fit, validation,
                            restarts=("random",), **settings)
        negative, _ = score_maps(features, targets, shuffled, test)
        fixed = normalize(features[:, test, d:])
        fixed_values = np.einsum("lnd,tnd->ltn", fixed, targets[:, test]).clip(-1, 1)**2
        start_values = np.einsum("nd,tnd->tn", directions[test, 0], targets[:, test]).clip(-1, 1)**2
        for layer in range(layers):
            for index, power in enumerate(powers):
                s = float(values[layer, index].mean())
                other = np.delete(cross[layer, index], index)
                rows.append(dict(
                    **metadata, layer=layer, power=power, split_seed=split_seed,
                    fit_samples=len(fit), validation_samples=len(validation), test_samples=len(test),
                    mean_error=1 - s, similarity=s, corrected_similarity=(s - 1 / d) / (1 - 1 / d),
                    mean_angle_degrees=float(np.degrees(np.arccos(np.sqrt(values[layer, index]))).mean()),
                    fixed_similarity=float(fixed_values[layer, index].mean()),
                    start_similarity=float(start_values[index].mean()),
                    shuffled_similarity=float(negative[layer, index].mean()),
                    target_specificity_margin=s - float(other.max()) if len(other) else None,
                    validation_similarity=float(fitted["validation_similarity"][layer, index]),
                    best_step=int(fitted["best_step"][layer, index]),
                    restart=str(fitted["restart"][layer, index])))
                for j, compared_power in enumerate(powers):
                    cross_rows.append(dict(**metadata, layer=layer, split_seed=split_seed,
                        fitted_power=power, scored_power=compared_power,
                        similarity=float(cross[layer, index, j])))
        np.savez(output / f"split-{split_seed}.npz", **fitted,
                 fit_indices=fit, validation_indices=validation, test_indices=test,
                 powers=np.asarray(powers))
    write_csv(output / "scores.csv", rows)
    write_csv(output / "cross-target-scores.csv", cross_rows)
    atomic_json(output / "complete.json", {"scores": len(rows), "powers": powers})
    return rows
