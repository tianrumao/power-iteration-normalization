# Direction metrics preserve invalid-output flags and negative chance-corrected scores.
import numpy as np
import torch
from src.model import readout, direction_error

def corrected(similarity, d=32):
    return (similarity - 1.0 / d) / (1.0 - 1.0 / d)

@torch.no_grad()
def score(model, dataset, device, limit=None):
    inputs, targets = dataset
    count = len(inputs) if limit is None else min(limit, len(inputs))
    errors = []
    invalid = 0
    for start in range(0, count, 128):
        x = inputs[start:min(start + 128, count)].to(device, dtype=next(model.parameters()).dtype)
        y = targets[start:min(start + 128, count)].to(device, dtype=next(model.parameters()).dtype)
        states, _ = model(x)
        prediction, valid = readout(states[-1])
        values = direction_error(prediction, y, valid)
        errors.append(values.double().cpu().numpy())
        invalid += int((~valid).sum())
    errors = np.concatenate(errors)
    return (dict(samples=count, mean_error=float(errors.mean()), mean_similarity=float(1 - errors.mean()), failures=invalid, at_99_99_percent=int((errors <= 0.0001).sum()), mean_angle_degrees=float(np.degrees(np.arcsin(np.sqrt(np.clip(errors, 0, 1)))).mean())), errors)

