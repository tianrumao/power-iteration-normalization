from dataclasses import dataclass

import numpy as np


@dataclass
class Samples:
    tokens: np.ndarray
    target: np.ndarray
    power: np.ndarray
    gap: np.ndarray
    eigenvalue_ratio: np.ndarray = None


def sample(size, d, n, rng, power_steps=4):
    """Generate unit-column Gaussian inputs and q_k = normalize((XX^T)^k a)."""
    if size < 1 or d < 2 or n < d or power_steps < 0:
        raise ValueError("Require size > 0, n >= d >= 2 and power_steps >= 0")
    x = rng.standard_normal((size, d, n))
    x /= np.linalg.norm(x, axis=1, keepdims=True)
    a = rng.standard_normal((size, d))
    a /= np.linalg.norm(a, axis=1, keepdims=True)
    s = x @ x.swapaxes(-1, -2)
    eigenvalues, eigenvectors = np.linalg.eigh(s)
    tokens = np.zeros((size, 2 * d, n + 1))
    tokens[:, :d, :n] = x
    tokens[:, d:, n] = a
    power = [a]
    for _ in range(power_steps):
        update = (s @ power[-1][..., None])[..., 0]
        power.append(update / np.linalg.norm(update, axis=1, keepdims=True))
    return Samples(tokens, eigenvectors[:, :, -1], np.stack(power, axis=1),
                   eigenvalues[:, -1] - eigenvalues[:, -2],
                   eigenvalues[:, -2] / eigenvalues[:, -1])


def splits(config):
    seeds = np.random.SeedSequence(config["seed"]).spawn(3)
    return {
        name: sample(config[f"{name}_size"], config["d"], config["n"],
                     np.random.default_rng(seed))
        for name, seed in zip(("train", "validation", "test"), seeds)
    }
