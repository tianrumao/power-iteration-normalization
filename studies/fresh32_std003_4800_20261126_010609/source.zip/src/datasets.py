"""Paired data with an explicit cache identity and intermediate probe labels."""

import hashlib
import json
import numpy as np
import torch

from src.data import sample
from .io import atomic_json, digest
from .power_targets import power_directions


def dataset(seed, cfg, output, cache):
    specification = {key: cfg[key] for key in (
        "data_epoch", "d", "n", "train_size", "validation_size", "test_size",
        "probe_samples", "max_power")}
    specification.update(generator="unit_gaussian_columns", version=2, seed=seed)
    identity = hashlib.sha256(json.dumps(specification, sort_keys=True).encode()).hexdigest()[:20]
    folder = cache / identity
    folder.mkdir(parents=True, exist_ok=True)
    streams = np.random.SeedSequence([cfg["data_epoch"], seed, 10723]).spawn(4)
    pools, manifests = {}, {}
    for name, count, stream in zip(
            ("train", "validation", "test", "probe"),
            (cfg["train_size"], cfg["validation_size"], cfg["test_size"], cfg["probe_samples"]), streams):
        xp, yp = folder / f"{name}-x.npy", folder / f"{name}-y.npy"
        if not xp.exists() or not yp.exists():
            examples = sample(count, cfg["d"], cfg["n"], np.random.default_rng(stream), power_steps=0)
            np.save(xp, examples.tokens.astype(np.float32))
            np.save(yp, examples.target.astype(np.float64 if name == "probe" else np.float32))
        x, y = np.load(xp, mmap_mode="c"), np.load(yp, mmap_mode="c")
        pools[name] = (torch.from_numpy(x), torch.from_numpy(y))
        manifests[name] = {"samples": count, "input_sha256": digest(x), "target_sha256": digest(y),
                           "input_shape": list(x.shape), "spawn_key": list(stream.spawn_key)}
    powers_path = folder / "probe-powers.npy"
    if not powers_path.exists():
        np.save(powers_path, power_directions(pools["probe"][0].numpy(), cfg["max_power"]))
    pools["probe_powers"] = np.load(powers_path, mmap_mode="r")
    atomic_json(output / f"seed-{seed}-data.json", {"specification": specification,
        "cache_identity": identity, "splits": manifests, "power_sha256": digest(pools["probe_powers"])})
    return pools
