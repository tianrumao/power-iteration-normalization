"""Persist final validation gaps and the user-defined cohort pause rule."""

import numpy as np

from .io import atomic_json, write_csv


def cohort_status(pairs, threshold=.1, minimum_pairs=8, maximum_fraction=.5):
    flagged = [p["seed"] for p in pairs if p["validation_gap"] > threshold]
    count = len(pairs)
    fraction = len(flagged) / count if count else 0.
    return {
        "completed_pairs": count, "flagged_count": len(flagged),
        "flagged_fraction": fraction, "flagged_seeds": flagged,
        "gap_threshold": threshold, "minimum_pairs_before_pause": minimum_pairs,
        "pause_fraction_threshold": maximum_fraction,
        "should_pause": count >= minimum_pairs and fraction > maximum_fraction,
    }


def save_gap_report(pairs, cfg, output):
    status = cohort_status(pairs, cfg["gap_flag_threshold"],
                           cfg["pause_minimum_pairs"], cfg["pause_flagged_fraction"])
    atomic_json(output / "progress.json", status)
    atomic_json(output / "pairs.json", pairs)
    write_csv(output / "seed-gaps.csv", [
        {"seed": p["seed"], "final_gap": p["validation_gap"]} for p in pairs])
    if not pairs:
        return status
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    positions = np.arange(len(pairs))
    values = np.asarray([p["validation_gap"] for p in pairs])
    colors = np.where(values > cfg["gap_flag_threshold"], "#d24b40", "#247ba0")
    fig, ax = plt.subplots(figsize=(12, 4.5))
    ax.bar(positions, values, color=colors, width=.7)
    ax.axhline(cfg["gap_flag_threshold"], color="#d24b40", linestyle="--", linewidth=1)
    ax.set_xticks(positions, [str(p["seed"]) for p in pairs], rotation=60, ha="right")
    ax.set_xlabel("Seed")
    ax.set_ylabel("Final layer-4 validation error gap")
    ax.set_ylim(0, max(.12, float(values.max()) * 1.22))
    for x, value in zip(positions, values):
        ax.text(x, value + .003, f"{value:.3f}", ha="center", va="bottom", fontsize=7, rotation=90)
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    temporary = output / "seed-gap.pending.png"
    fig.savefig(temporary, dpi=180)
    temporary.replace(output / "seed-gap.png")
    plt.close(fig)
    return status
