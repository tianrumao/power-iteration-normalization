"""Run fresh paired training, then retain probes and bypass results for all seeds."""

import argparse
import csv
import hashlib
import json
import platform
import shutil
import traceback
from pathlib import Path

import numpy as np
import torch

from src.cohort_report import save_gap_report
from src.datasets import dataset
from src.direction_probes import probe_powers
from src.io import atomic_json, write_csv
from src.metrics import score
from src.pairing import qualify_pair, bypass_layers
from src.power_targets import calibrate
from src.probe_math import collect_query_states
from src.training import train_arm, model_for


def validate_config(cfg):
    if cfg["masks"] != ["111", "000"] or (cfg["d"], cfg["n"], cfg["depth"]) != (32, 64, 4):
        raise ValueError("Keep only 111/000 with d=32, n=64 and four layers")
    if len(set(cfg["seeds"])) != len(cfg["seeds"]) or not cfg["seeds"]:
        raise ValueError("Provide distinct training seeds")
    if not 2 <= cfg["probe_count"] <= cfg["max_power"]:
        raise ValueError("Invalid intermediate targets")
    if cfg["precision"] not in ("float32", "float64"):
        raise ValueError("Unsupported precision")
    if len(cfg["budgets"]) != 1 or cfg["budgets"][0] < 1:
        raise ValueError("Use one positive update cap")
    if cfg["schedule_horizon"] != cfg["budgets"][0]:
        raise ValueError("The schedule horizon must match the update budget")
    if not 0 <= cfg["gap_flag_threshold"] <= 1 or not 0 <= cfg["pause_flagged_fraction"] <= 1:
        raise ValueError("Invalid gap flag or pause fraction")
    if cfg["pause_minimum_pairs"] < 1:
        raise ValueError("The pause rule requires a positive minimum cohort size")
    for key in ("train_size", "validation_size", "test_size", "probe_samples",
                "batch_size", "evaluation_every", "calibration_samples"):
        if cfg[key] < 1:
            raise ValueError(f"{key} must be positive")


def summarize(probes, pairs, output, matched_only=False):
    included = {p["seed"] for p in pairs if not matched_only or not p["gap_gt_0_1"]}
    per_model = {}
    for row in probes:
        if row["seed"] in included:
            key = row["seed"], row["mask"], row["layer"], row["power"]
            per_model.setdefault(key, []).append(row["mean_error"])
    rows = []
    for layer, power in sorted({(key[2], key[3]) for key in per_model}):
        deltas = []
        for seed in included:
            on, off = (per_model.get((seed, mask, layer, power)) for mask in ("111", "000"))
            if on is not None and off is not None:
                deltas.append(float(np.mean(on) - np.mean(off)))
        for mask in ("111", "000"):
            items = [np.mean(values) for key, values in per_model.items()
                     if key[1:] == (mask, layer, power)]
            if items:
                rows.append({"layer": layer, "power": power, "mask": mask,
                    "model_seeds": len(items), "mean_error": float(np.mean(items)),
                    "sd_across_model_seeds": float(np.std(items, ddof=1)) if len(items) > 1 else None,
                    "paired_seeds": len(deltas),
                    "paired_error_on_minus_off": float(np.mean(deltas)) if deltas else None})
    name = "matched-probe-summary.csv" if matched_only else "probe-summary.csv"
    write_csv(output / name, rows)


def paused(output, reason, **details):
    atomic_json(output / "paused.json", {"reason": reason, **details})
    print("STUDY_PAUSED " + json.dumps({"reason": reason, **details}), flush=True)


def read_rows(path):
    with path.open(newline="") as handle:
        rows = list(csv.DictReader(handle))
    for row in rows:
        for key in ("seed", "layer", "power", "split_seed"):
            if key in row:
                row[key] = int(row[key])
        if "mean_error" in row:
            row["mean_error"] = float(row["mean_error"])
    return rows


def run(cfg, output, cache, device, phase="calibrate"):
    validate_config(cfg)
    output.mkdir(parents=True, exist_ok=True)
    config_path = output / "config.json"
    if config_path.exists() and json.loads(config_path.read_text()) != cfg:
        raise ValueError("Use a fresh output directory when configuration changes")
    atomic_json(config_path, cfg)
    source = Path(__file__).resolve().parents[1]
    hashes = {str(p.relative_to(source)): hashlib.sha256(p.read_bytes()).hexdigest()
              for root in (source / "src", source / "experiments") for p in sorted(root.rglob("*.py"))}
    hashes_path = output / "source-hashes.json"
    if hashes_path.exists() and json.loads(hashes_path.read_text()) != hashes:
        raise ValueError("Source changed: use a fresh output directory")
    atomic_json(hashes_path, hashes)
    if not (output / "source").exists():
        for name in ("src", "experiments", "configs"):
            shutil.copytree(source / name, output / "source" / name,
                            ignore=shutil.ignore_patterns("__pycache__"))
    atomic_json(output / "protocol.json", {
        "update_budget": max(cfg["budgets"]), "initialization_sd": cfg["init_std"],
        "task_target": "leading eigenvector; final layer-4 normalized direction readout",
        "probe_target": "q_k = normalize((XX^T)^k a), eight independently calibrated targets",
        "probe_loss": "mean(1 - squared cosine), bias-free linear maps; validation-only checkpoint selection",
        "pairing": "same data, initialization, batches, precision and learning-rate schedule",
        "gap": "absolute difference of final validation mean(1 - squared cosine) errors",
        "flag_rule": f"gap strictly greater than {cfg['gap_flag_threshold']}; retain every seed",
        "pause_rule": f"at least {cfg['pause_minimum_pairs']} pairs and flagged fraction strictly greater than {cfg['pause_flagged_fraction']}",
        "absolute_validation_error_gate": None,
        "failure_policy": "save and halt on numerical or implementation failures; flag large performance gaps and apply cohort pause rule",
        "analysis": "save test, probe and bypass results for every model, including flagged seeds; also summarize unflagged pairs separately",
        "layers": "input 0 and network layers 1-4, eight power probes per layer",
        "negative_control": "permute fit and validation labels separately; true test labels retained",
        "bypass": "skip residual update, keep normalizer; length-matched and plain bypass",
        "primary_contrast": "[(delta_E4-delta_E1)_on - (delta_E4-delta_E1)_off]",
        "python": platform.python_version(), "numpy": str(np.__version__),
        "torch": str(torch.__version__), "device": str(device),
    })
    selection_path = output / "power-selection.json"
    if selection_path.exists():
        selection = json.loads(selection_path.read_text())
    else:
        selection = calibrate(d=cfg["d"], n=cfg["n"], samples=cfg["calibration_samples"],
            seed=cfg["calibration_seed"], maximum=cfg["max_power"], count=cfg["probe_count"])
        atomic_json(selection_path, selection)
    print("Selected intermediate powers:", selection["powers"], flush=True)
    if phase == "calibrate":
        return selection
    arms, pairs = [], []
    for seed in cfg["seeds"]:
        if (output / "pause.request").exists():
            paused(output, "user_request", completed_pairs=len(pairs))
            return
        print(f"SEED_START seed={seed}", flush=True)
        pools = dataset(seed, cfg, output, cache)
        selected = {}
        for mask in cfg["masks"]:
            try:
                selected[mask] = train_arm(seed, mask, cfg, pools, output, device)
                arms.append(selected[mask])
            except Exception:
                folder = output / f"seed-{seed}" / mask
                folder.mkdir(parents=True, exist_ok=True)
                (folder / "failure.txt").write_text(traceback.format_exc())
                atomic_json(output / "arms.json", arms)
                atomic_json(output / "halted.json", {"seed": seed, "mask": mask,
                    "reason": "training_failure", "failure_file": str(folder / "failure.txt")})
                raise
        pairing = [json.loads((output / f"seed-{seed}" / mask / "pairing.json").read_text())
                   for mask in cfg["masks"]]
        for key in ("initial_sha256", "batch_sha256"):
            if pairing[0][key] != pairing[1][key]:
                raise AssertionError("Model pair is not matched")
        pair = {"seed": seed, **qualify_pair(selected["111"], selected["000"],
                cfg["gap_flag_threshold"], required_step=max(cfg["budgets"]))}
        if "validation_gap" not in pair or pair["reason"] not in ("passed", "validation_gap"):
            raise RuntimeError(f"Invalid final outputs for seed {seed}: {pair}")
        pair.update(error_111=selected["111"]["validation_error"],
                    error_000=selected["000"]["validation_error"],
                    gap_gt_0_1=pair["validation_gap"] > cfg["gap_flag_threshold"],
                    same_initialization=True, same_batches=True)
        pairs.append(pair)
        atomic_json(output / "arms.json", arms)
        status = save_gap_report(pairs, cfg, output)
        print("PAIR_RESULT " + json.dumps({**pair, "completed_pairs": status["completed_pairs"],
            "flagged_count": status["flagged_count"], "flagged_fraction": status["flagged_fraction"]}), flush=True)
        del pools
        if status["should_pause"]:
            paused(output, "flagged_fraction", **status)
            return
    atomic_json(output / "training-complete.json", {"pairs": len(pairs), **status})
    print("TRAINING_COMPLETE " + json.dumps(status), flush=True)

    # Final gap reporting precedes the more expensive probe and bypass analysis.
    all_probes, all_bypass = [], []
    for pair in pairs:
        seed = pair["seed"]
        if (output / "pause.request").exists():
            paused(output, "user_request_during_analysis", seed=seed)
            return
        print(f"ANALYSIS_START seed={seed}", flush=True)
        pools = dataset(seed, cfg, output, cache)
        contrasts = {}
        for mask in cfg["masks"]:
            folder = output / f"seed-{seed}" / mask
            analysis_path = folder / "analysis.json"
            if analysis_path.exists():
                analysis = json.loads(analysis_path.read_text())
                rows = read_rows(folder / "power_probes/scores.csv")
                all_probes.extend(rows)
                all_bypass.extend(analysis["bypass_rows"])
                contrasts[mask] = analysis["contrasts"]
                for arm in arms:
                    if (arm["seed"], arm["mask"]) == (seed, mask):
                        arm["test_error"] = analysis["test"]["mean_error"]
                continue
            model = model_for(mask, cfg["init_std"], device, cfg["precision"])
            model.load_state_dict(torch.load(folder / "selected.pt", map_location=device, weights_only=True))
            model.eval().requires_grad_(False)
            metrics, _ = score(model, pools["test"], device)
            atomic_json(folder / "test.json", metrics)
            bypass, contrasts[mask] = bypass_layers(model, pools["test"], device)
            bypass = [dict(seed=seed, mask=mask, **r) for r in bypass]
            features, _ = collect_query_states(model, pools["probe"][0].numpy(), cfg["batch_size"], device)
            rows = probe_powers(features, pools["probe_powers"], selection["powers"], cfg,
                folder / "power_probes", {"seed": seed, "mask": mask}, device)
            all_probes.extend(rows)
            all_bypass.extend(bypass)
            atomic_json(analysis_path, {"test": metrics, "bypass_rows": bypass, "contrasts": contrasts[mask]})
            for arm in arms:
                if (arm["seed"], arm["mask"]) == (seed, mask):
                    arm["test_error"] = metrics["mean_error"]
        pair.update({f"{mode}_contrast_on_minus_off": contrasts["111"][mode] - contrasts["000"][mode]
                     for mode in ("bypass", "matched")})
        pair["bypass_valid"] = all(r["invalid_outputs"] == 0 and r["intact_invalid_outputs"] == 0
                                   for r in all_bypass if r["seed"] == seed)
        atomic_json(output / "arms.json", arms)
        atomic_json(output / "pairs.json", pairs)
        write_csv(output / "power-probes.csv", all_probes)
        write_csv(output / "bypass.csv", all_bypass)
        summarize(all_probes, pairs, output)
        summarize(all_probes, pairs, output, matched_only=True)
        del pools
        print(f"ANALYSIS_COMPLETE seed={seed}", flush=True)
    atomic_json(output / "complete.json", {"candidate_pairs": len(pairs),
        "eligible_pairs": sum(not p["gap_gt_0_1"] for p in pairs),
        "flagged_pairs": sum(p["gap_gt_0_1"] for p in pairs),
        "probe_scores": len(all_probes), "status": "complete"})
    print("STUDY_COMPLETE", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--cache", type=Path, required=True)
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cpu")
    parser.add_argument("--phase", choices=("calibrate", "train"), default="calibrate")
    args = parser.parse_args()
    torch.set_num_threads(1)
    run(json.loads(args.config.read_text()), args.output, args.cache, torch.device(args.device), args.phase)


if __name__ == "__main__":
    main()
