import copy
import json
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

import numpy as np
import torch

from src.data import sample
from src.model import Model, unit
from src.direction_probes import fit_maps, score_maps, partition, similarity
from src.pairing import qualify_pair, bypass_layers
from src.power_targets import power_directions, select_powers
from src.training import train_arm
from src.cohort_report import cohort_status
from experiments.run_study import run


ROOT = Path(__file__).resolve().parents[1]


class PowerProbeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(1)

    def test_intermediate_targets_equal_explicit_matrix_powers(self):
        examples = sample(12, 4, 8, np.random.default_rng(1), power_steps=16)
        actual = power_directions(examples.tokens, 16)
        np.testing.assert_allclose(actual, examples.power, atol=1e-13)
        s = examples.tokens[:, :4, :-1] @ examples.tokens[:, :4, :-1].swapaxes(-1, -2)
        for k in (1, 3, 8, 16):
            expected = (np.linalg.matrix_power(s, k) @ examples.power[:, 0, :, None])[..., 0]
            expected /= np.linalg.norm(expected, axis=-1, keepdims=True)
            np.testing.assert_allclose(actual[:, k], expected, atol=1e-12)

    def test_old_generator_preserved_and_eigenvector_is_not_q16(self):
        short = sample(100, 4, 8, np.random.default_rng(12))
        long = sample(100, 4, 8, np.random.default_rng(12), power_steps=16)
        np.testing.assert_array_equal(short.tokens, long.tokens)
        np.testing.assert_array_equal(short.target, long.target)
        np.testing.assert_array_equal(short.power, long.power[:, :5])
        self.assertGreater(float(np.mean(1 - np.sum(long.power[:, 16] * long.target, axis=-1)**2)), 0)

    def test_sign_and_scale_invariance(self):
        generator = torch.Generator().manual_seed(11)
        prediction = torch.randn(60, 4, dtype=torch.float64, generator=generator)
        target = unit(torch.randn(60, 4, dtype=torch.float64, generator=generator), -1)[0]
        original = similarity(prediction, target)
        torch.testing.assert_close(original, similarity(-prediction, target))
        torch.testing.assert_close(original, similarity(prediction, -target))
        torch.testing.assert_close(original, similarity(prediction * 1e100, target))

    def test_probe_positive_control_and_disjoint_splits(self):
        rng = np.random.default_rng(8)
        targets = rng.normal(size=(2, 90, 4))
        targets /= np.linalg.norm(targets, axis=-1, keepdims=True)
        features = np.concatenate((np.zeros_like(targets), targets), axis=-1)
        fit, val, test = partition(90, 0)
        self.assertFalse(set(fit) & set(val) or set(fit) & set(test) or set(val) & set(test))
        fitted = fit_maps(features, targets, fit, val, steps=0, restarts=("fixed",))
        values, _ = score_maps(features, targets, fitted, test)
        np.testing.assert_allclose(values[[0, 1], [0, 1]], 1, atol=1e-12)

    def test_selection_and_pair_gate(self):
        data = sample(200, 4, 8, np.random.default_rng(42), power_steps=16)
        powers, _ = select_powers(data.power, 8)
        self.assertEqual((len(powers), len(set(powers)), powers[0], powers[-1]), (8, 8, 1, 16))
        on = {"selected_step": 4800, "validation_error": .19}
        self.assertTrue(qualify_pair(on, dict(on, validation_error=.18))["eligible"])
        self.assertFalse(qualify_pair(on, dict(on, validation_error=.35))["eligible"])
        self.assertFalse(qualify_pair(on, dict(on, selected_step=2400), required_step=4800)["eligible"])
        self.assertTrue(qualify_pair(dict(on, validation_error=.30), dict(on, validation_error=.31))["eligible"])
        self.assertFalse(qualify_pair(on, None)["eligible"])

    def test_zero_update_bypass_and_frozen_backbone(self):
        examples = sample(10, 4, 8, np.random.default_rng(1))
        for norm_on in (True, False):
            model = Model(4, norm_on, .01).double().eval()
            for parameter in model.parameters():
                parameter.data.zero_()
            before = copy.deepcopy(model.state_dict())
            rows, contrast = bypass_layers(model, (torch.tensor(examples.tokens), torch.tensor(examples.target)), "cpu")
            self.assertEqual(len(rows), 8)
            for row in rows:
                self.assertAlmostEqual(row["delta_final_error"], 0, places=12)
                self.assertEqual(row["invalid_outputs"], 0)
            for name, parameter in model.state_dict().items():
                torch.testing.assert_close(parameter, before[name])

    def test_small_full_pipeline(self):
        cfg = json.loads((ROOT / "configs/study.json").read_text())
        cfg.update(seeds=[101], budgets=[2], schedule_horizon=2, warmup_steps=0,
                   train_size=24, validation_size=16, test_size=16, probe_samples=40,
                   calibration_samples=48, batch_size=8, init_std=.005, evaluation_every=1,
                   gap_flag_threshold=.99999,
                   probe_split_seeds=[0], probe_steps=1, probe_batch_size=8)
        with tempfile.TemporaryDirectory() as tmp:
            output, cache = Path(tmp) / "results", Path(tmp) / "cache"
            run(cfg, output, cache, torch.device("cpu"), phase="train")
            complete = json.loads((output / "complete.json").read_text())
            self.assertEqual(complete["eligible_pairs"], 1)
            self.assertEqual(complete["probe_scores"], 2 * 5 * 8)
            pair = json.loads((output / "pairs.json").read_text())[0]
            self.assertTrue(pair["bypass_valid"])
            self.assertIn("matched_contrast_on_minus_off", pair)
            arm = json.loads((output / "seed-101/111/selection.json").read_text())
            self.assertEqual(arm["selected_step"], 2)
            pools = {"train": (torch.empty(0), torch.empty(0))}
            self.assertEqual(train_arm(101, "111", cfg, pools, output, "cpu"), arm)
            with patch("experiments.run_study.probe_powers", side_effect=AssertionError("Do not refit completed probes")):
                run(cfg, output, cache, torch.device("cpu"), phase="train")
            resumed = json.loads((output / "arms.json").read_text())
            self.assertTrue(all("test_error" in a for a in resumed))

    def test_large_gaps_are_retained_and_analyzed(self):
        cfg = json.loads((ROOT / "configs/study.json").read_text())
        cfg.update(seeds=[101, 102], budgets=[2], schedule_horizon=2, warmup_steps=0,
                   train_size=24, validation_size=16, test_size=16, probe_samples=40,
                   calibration_samples=48, batch_size=8, init_std=.005,
                   evaluation_every=1, gap_flag_threshold=0.,
                   probe_split_seeds=[0], probe_steps=1, probe_batch_size=8)
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "results"
            run(cfg, output, Path(tmp) / "cache", torch.device("cpu"), phase="train")
            complete = json.loads((output / "complete.json").read_text())
            self.assertEqual(complete["flagged_pairs"], 2)
            self.assertEqual(complete["probe_scores"], 4 * 5 * 8)
            self.assertTrue((output / "seed-102/111/test.json").exists())
            self.assertTrue((output / "seed-gap.png").exists())
            self.assertEqual((output / "seed-gaps.csv").read_text().splitlines()[0], "seed,final_gap")

    def test_pause_rule_counts_and_strict_boundaries(self):
        pairs = [{"seed": i, "validation_gap": .11 if i < 4 else .1} for i in range(8)]
        self.assertEqual(cohort_status(pairs)["flagged_count"], 4)
        self.assertFalse(cohort_status(pairs)["should_pause"])
        pairs[4]["validation_gap"] = .12
        self.assertTrue(cohort_status(pairs)["should_pause"])
        self.assertFalse(cohort_status(pairs[:7])["should_pause"])

    def test_cohort_pause_prevents_starting_next_seed(self):
        cfg = json.loads((ROOT / "configs/study.json").read_text())
        cfg.update(seeds=[101, 102], budgets=[2], schedule_horizon=2, warmup_steps=0,
                   train_size=24, validation_size=16, test_size=16, probe_samples=40,
                   calibration_samples=48, batch_size=8, init_std=.005,
                   evaluation_every=1, gap_flag_threshold=0., pause_minimum_pairs=1)
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "results"
            run(cfg, output, Path(tmp) / "cache", torch.device("cpu"), phase="train")
            record = json.loads((output / "paused.json").read_text())
            self.assertEqual(record["reason"], "flagged_fraction")
            self.assertFalse((output / "seed-102").exists())
            self.assertFalse((output / "complete.json").exists())


if __name__ == "__main__":
    unittest.main()
